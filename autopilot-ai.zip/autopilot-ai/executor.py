"""
executor.py – Playwright-based browser execution engine.

BrowserAgent handles:
  • open_url / click / type / extract / wait / scroll
  • Retry logic per step (up to MAX_RETRIES)
  • Multiple selector strategies  (CSS → XPath → text=)
  • Dynamic waits (page.wait_for_selector)
  • Auto-popup dismissal
  • Per-step screenshots
"""

import asyncio
from pathlib import Path
from typing import Any

from playwright.async_api import (
    Page,
    Browser,
    BrowserContext,
    async_playwright,
    TimeoutError as PlaywrightTimeout,
)

import config
from logger import get_logger, log_step_start, log_step_success, log_step_failure
from utils import screenshot_path, normalise_selector, sanitise_url

log = get_logger(__name__)


class BrowserAgent:
    """Wraps a Playwright browser and executes structured step lists."""

    def __init__(self) -> None:
        self._playwright = None
        self._browser: Browser | None = None
        self._context: BrowserContext | None = None
        self.page: Page | None = None

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Launch browser and create a fresh page."""
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=config.HEADLESS,
            slow_mo=config.SLOW_MO,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        self._context = await self._browser.new_context(
            viewport={"width": 1280, "height": 900},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            java_script_enabled=True,
        )
        self._context.set_default_timeout(config.BROWSER_TIMEOUT)
        self.page = await self._context.new_page()
        self.page.set_default_navigation_timeout(config.NAVIGATION_TIMEOUT)
        log.info("Browser launched (headless=%s).", config.HEADLESS)

    async def stop(self) -> None:
        """Close everything cleanly."""
        try:
            if self._context:
                await self._context.close()
            if self._browser:
                await self._browser.close()
            if self._playwright:
                await self._playwright.stop()
        except Exception as exc:
            log.debug("Cleanup warning: %s", exc)

    # ── Popup dismissal ───────────────────────────────────────────────────────

    async def _dismiss_popups(self) -> None:
        """Try every known popup/cookie selector and click if visible."""
        for sel in config.POPUP_SELECTORS:
            try:
                btn = self.page.locator(sel).first
                if await btn.is_visible(timeout=1000):
                    await btn.click(timeout=2000)
                    log.debug("Dismissed popup: %s", sel)
                    await asyncio.sleep(0.5)
            except Exception:
                pass   # selector not found / not visible – that's fine

    # ── Core actions ──────────────────────────────────────────────────────────

    async def open_url(self, url: str) -> dict:
        url = sanitise_url(url)
        await self.page.goto(url, wait_until="domcontentloaded")
        await self._dismiss_popups()
        return {"url": url, "title": await self.page.title()}

    async def click(self, selector: str) -> dict:
        for sel in normalise_selector(selector):
            try:
                await self.page.wait_for_selector(sel, state="visible", timeout=config.BROWSER_TIMEOUT)
                await self.page.click(sel)
                await self._dismiss_popups()
                return {"clicked": sel}
            except Exception:
                continue
        raise RuntimeError(f"click: no selector matched for {selector!r}")

    async def type(self, selector: str, text: str) -> dict:
        # If text ends with \n, split it off and press Enter separately
        press_enter = text.endswith("\n")
        clean_text  = text.rstrip("\n")

        for sel in normalise_selector(selector):
            try:
                await self.page.wait_for_selector(sel, state="visible", timeout=config.BROWSER_TIMEOUT)
                await self.page.fill(sel, clean_text)
                if press_enter:
                    await self.page.press(sel, "Enter")
                    await self.page.wait_for_load_state("domcontentloaded")
                return {"typed": clean_text, "enter_pressed": press_enter}
            except Exception:
                continue
        raise RuntimeError(f"type: no selector matched for {selector!r}")

    async def extract(self, selector: str) -> dict:
        results: list[str] = []
        for sel in normalise_selector(selector):
            try:
                await self.page.wait_for_selector(sel, timeout=config.BROWSER_TIMEOUT)
                elements = await self.page.query_selector_all(sel)
                for el in elements[:20]:   # cap at 20 items
                    text = (await el.inner_text()).strip()
                    if text:
                        results.append(text)
                if results:
                    return {"selector": sel, "extracted": results}
            except Exception:
                continue
        return {"selector": selector, "extracted": results}

    async def wait(self, seconds: str) -> dict:
        secs = float(seconds) if seconds else 1.0
        secs = min(secs, 30)   # safety cap
        await asyncio.sleep(secs)
        return {"waited_seconds": secs}

    async def scroll(self, value: str = "down") -> dict:
        direction = (value or "down").lower()
        if direction == "up":
            await self.page.evaluate("window.scrollBy(0, -600)")
        else:
            await self.page.evaluate("window.scrollBy(0, 600)")
        return {"scrolled": direction}

    # ── Screenshot ────────────────────────────────────────────────────────────

    async def take_screenshot(self, label: str = "") -> str:
        path = screenshot_path(label)
        await self.page.screenshot(path=path, full_page=False)
        log.debug("Screenshot saved: %s", path)
        return path

    # ── Main execution loop ───────────────────────────────────────────────────

    async def execute_steps(self, steps: list[dict]) -> dict[str, Any]:
        """
        Execute a list of steps with per-step retry logic.
        Returns a summary dict with results, errors, and screenshot paths.
        """
        results: list[dict]  = []
        screenshots: list[str] = []
        extracted_data: dict   = {}
        errors: list[str]      = []

        await self.start()

        try:
            for idx, step in enumerate(steps, start=1):
                action      = step.get("action", "").lower()
                selector    = step.get("selector", "")
                value       = step.get("value", "")
                description = step.get("description", action)

                log_step_start(log, idx, description)

                step_result: dict | None = None
                last_error: str          = ""

                for attempt in range(1, config.MAX_RETRIES + 1):
                    try:
                        if action == "open_url":
                            step_result = await self.open_url(value)
                        elif action == "click":
                            step_result = await self.click(selector)
                        elif action == "type":
                            step_result = await self.type(selector, value)
                        elif action == "extract":
                            step_result = await self.extract(selector)
                            # accumulate extracted content
                            key = description or selector
                            extracted_data[key] = step_result.get("extracted", [])
                        elif action == "wait":
                            step_result = await self.wait(value)
                        elif action == "scroll":
                            step_result = await self.scroll(value)
                        else:
                            log.warning("Unknown action %r – skipping.", action)
                            step_result = {"skipped": True}

                        break   # success – exit retry loop

                    except (PlaywrightTimeout, Exception) as exc:
                        last_error = str(exc)
                        log.warning(
                            "Step %d attempt %d/%d failed: %s",
                            idx, attempt, config.MAX_RETRIES, exc,
                        )
                        if attempt < config.MAX_RETRIES:
                            await asyncio.sleep(config.RETRY_DELAY)

                # ── Screenshot after each step ────────────────────────────────
                try:
                    ss_path = await self.take_screenshot(f"step{idx}_{action}")
                    screenshots.append(ss_path)
                except Exception:
                    pass

                if step_result is not None:
                    log_step_success(log, idx, description)
                    results.append({
                        "step": idx,
                        "action": action,
                        "description": description,
                        "status": "success",
                        "result": step_result,
                    })
                else:
                    log_step_failure(log, idx, description, last_error)
                    errors.append(f"Step {idx} ({description}): {last_error}")
                    results.append({
                        "step": idx,
                        "action": action,
                        "description": description,
                        "status": "failed",
                        "error": last_error,
                    })

        finally:
            await self.stop()

        return {
            "steps_executed": len(results),
            "step_results":   results,
            "extracted_data": extracted_data,
            "screenshots":    screenshots,
            "errors":         errors,
        }
