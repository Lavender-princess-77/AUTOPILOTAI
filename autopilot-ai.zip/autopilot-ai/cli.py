"""
cli.py – Command-line interface for AutoPilot AI.

Usage
-----
    python cli.py "Open google and search AI tools"
    python cli.py --task "Go to amazon and find laptop prices" --headless false
    python cli.py --interactive
"""

import argparse
import asyncio
import json
import os
import sys

# Allow running from project root
sys.path.insert(0, os.path.dirname(__file__))

import config
from executor import BrowserAgent
from logger import get_logger
from planner import generate_steps

log = get_logger("cli")


async def _run(task: str, headless: bool) -> None:
    config.HEADLESS = headless

    print(f"\n🤖  AutoPilot AI – Task: {task!r}\n")

    # ── Plan ──────────────────────────────────────────────────────────────────
    print("📋  Planning steps …")
    steps = await generate_steps(task)
    print(f"    {len(steps)} steps generated.\n")
    for i, s in enumerate(steps, 1):
        print(f"    {i}. [{s['action'].upper():10}] {s['description']}")

    print()

    # ── Execute ───────────────────────────────────────────────────────────────
    print("🚀  Executing …\n")
    agent = BrowserAgent()
    result = await agent.execute_steps(steps)

    # ── Summary ───────────────────────────────────────────────────────────────
    print("\n" + "═" * 60)
    print("✅  DONE")
    print(f"    Steps executed : {result['steps_executed']}")
    print(f"    Errors         : {len(result['errors'])}")
    print(f"    Screenshots    : {len(result['screenshots'])}")

    if result["extracted_data"]:
        print("\n📦  Extracted Data:")
        print(json.dumps(result["extracted_data"], indent=2, ensure_ascii=False))

    if result["errors"]:
        print("\n⚠️  Errors:")
        for err in result["errors"]:
            print(f"   • {err}")

    if result["screenshots"]:
        print("\n🖼️  Screenshots saved:")
        for ss in result["screenshots"]:
            print(f"   • {ss}")

    print("═" * 60 + "\n")


def _interactive() -> None:
    print("\n🤖  AutoPilot AI – Interactive Mode")
    print("    Type a task and press Enter.  'quit' to exit.\n")
    while True:
        try:
            task = input("Task > ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break
        if not task:
            continue
        if task.lower() in ("quit", "exit", "q"):
            print("Bye!")
            break
        asyncio.run(_run(task, headless=True))


def main() -> None:
    parser = argparse.ArgumentParser(
        description="AutoPilot AI – run browser tasks from the command line"
    )
    parser.add_argument("task", nargs="?", help="Task description (natural language)")
    parser.add_argument(
        "--headless", default="true", choices=["true", "false"],
        help="Run browser headlessly (default: true)"
    )
    parser.add_argument(
        "--interactive", "-i", action="store_true",
        help="Launch interactive prompt loop"
    )
    args = parser.parse_args()

    headless = args.headless.lower() == "true"

    if args.interactive:
        _interactive()
    elif args.task:
        asyncio.run(_run(args.task, headless=headless))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
