"""
utils.py – Small, reusable helpers used across the project.
"""

import asyncio
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

import config
from logger import get_logger

log = get_logger(__name__)


# ── Screenshot helpers ────────────────────────────────────────────────────────

def screenshot_path(label: str = "") -> str:
    """Return a unique screenshot file path inside SCREENSHOTS_DIR."""
    Path(config.SCREENSHOTS_DIR).mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")
    slug = re.sub(r"[^a-zA-Z0-9_-]", "_", label)[:40] if label else "step"
    return str(Path(config.SCREENSHOTS_DIR) / f"{ts}_{slug}.png")


# ── JSON extraction ───────────────────────────────────────────────────────────

def extract_json_from_text(text: str) -> Any:
    """
    Try to extract the first valid JSON array or object from raw LLM output.
    The LLM may wrap JSON in markdown fences – this handles that gracefully.
    """
    # Strip ```json ... ``` fences
    fenced = re.search(r"```(?:json)?\s*([\s\S]+?)\s*```", text)
    if fenced:
        text = fenced.group(1)

    # Try the whole string first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to find the first [...] or {...} block
    for pattern in (r"(\[[\s\S]+\])", r"(\{[\s\S]+\})"):
        match = re.search(pattern, text)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                continue

    raise ValueError(f"No valid JSON found in LLM output:\n{text[:500]}")


# ── Retry decorator ───────────────────────────────────────────────────────────

def async_retry(max_attempts: int = None, delay: float = None):
    """
    Decorator that retries an async function up to *max_attempts* times,
    waiting *delay* seconds between attempts.
    """
    _max = max_attempts or config.MAX_RETRIES
    _delay = delay if delay is not None else config.RETRY_DELAY

    def decorator(fn):
        async def wrapper(*args, **kwargs):
            last_exc: Exception | None = None
            for attempt in range(1, _max + 1):
                try:
                    return await fn(*args, **kwargs)
                except Exception as exc:
                    last_exc = exc
                    log.warning(
                        "%s – attempt %d/%d failed: %s",
                        fn.__name__, attempt, _max, exc,
                    )
                    if attempt < _max:
                        await asyncio.sleep(_delay)
            raise last_exc  # re-raise after all attempts exhausted
        wrapper.__name__ = fn.__name__
        return wrapper
    return decorator


# ── Selector normalisation ────────────────────────────────────────────────────

def normalise_selector(raw: str) -> list[str]:
    """
    Given a raw selector string, return an ordered list of selectors to try:
    1. The original (CSS / XPath / Playwright text=)
    2. An XPath variant (if the original looks like a CSS selector)
    3. A text-based selector (if a visible label can be inferred)
    """
    selectors = [raw]

    # If it's already an XPath, no need to wrap further
    if raw.startswith("//") or raw.startswith("xpath="):
        return selectors

    # Add an XPath equivalent for common CSS id/class patterns
    id_match = re.match(r"^#([\w-]+)$", raw)
    if id_match:
        selectors.append(f"xpath=//*[@id='{id_match.group(1)}']")

    cls_match = re.match(r"^\.([\w-]+)$", raw)
    if cls_match:
        selectors.append(f"xpath=//*[contains(@class,'{cls_match.group(1)}')]")

    # Infer a text selector from common button/link patterns
    text_match = re.search(r"['\"]([^'\"]{3,})['\"]", raw)
    if text_match:
        selectors.append(f"text={text_match.group(1)}")

    return selectors


# ── Misc ──────────────────────────────────────────────────────────────────────

def sanitise_url(url: str) -> str:
    """Ensure a URL has a scheme."""
    if not url.startswith(("http://", "https://")):
        return "https://" + url
    return url
