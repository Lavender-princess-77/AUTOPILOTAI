"""
logger.py – Centralised logging for AutoPilot AI.

Every module imports `get_logger(__name__)` and gains:
  • Console output  (INFO+)
  • File output     (DEBUG+)  → logs/run.log
  • Step-level helpers: log_step_start / log_step_success / log_step_failure
"""

import logging
import os
import sys
from datetime import datetime
from pathlib import Path

import config


def _ensure_log_dir() -> None:
    Path(config.LOGS_DIR).mkdir(parents=True, exist_ok=True)


class _StepFormatter(logging.Formatter):
    """Pretty-print log lines with colour codes for console."""

    LEVEL_COLOURS = {
        logging.DEBUG:    "\033[36m",   # cyan
        logging.INFO:     "\033[32m",   # green
        logging.WARNING:  "\033[33m",   # yellow
        logging.ERROR:    "\033[31m",   # red
        logging.CRITICAL: "\033[35m",   # magenta
    }
    RESET = "\033[0m"

    def format(self, record: logging.LogRecord) -> str:
        colour = self.LEVEL_COLOURS.get(record.levelno, "")
        ts = datetime.fromtimestamp(record.created).strftime("%H:%M:%S")
        level = f"{colour}{record.levelname:<8}{self.RESET}"
        return f"{ts} | {level} | {record.name} | {record.getMessage()}"


def get_logger(name: str) -> logging.Logger:
    """Return (or create) a named logger wired to console + file."""
    _ensure_log_dir()
    logger = logging.getLogger(name)

    if logger.handlers:          # already configured
        return logger

    logger.setLevel(logging.DEBUG)

    # ── Console handler ──────────────────────────────────────────────────────
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(_StepFormatter())
    logger.addHandler(ch)

    # ── File handler ─────────────────────────────────────────────────────────
    fh = logging.FileHandler(config.LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    logger.addHandler(fh)
    logger.propagate = False
    return logger


# ── Convenience helpers ───────────────────────────────────────────────────────

def log_step_start(logger: logging.Logger, step_index: int, description: str) -> None:
    logger.info("▶ Step %d START  – %s", step_index, description)


def log_step_success(logger: logging.Logger, step_index: int, description: str) -> None:
    logger.info("✔ Step %d OK     – %s", step_index, description)


def log_step_failure(
    logger: logging.Logger, step_index: int, description: str, error: str
) -> None:
    logger.error("✖ Step %d FAIL   – %s | error=%s", step_index, description, error)


def read_log_file() -> str:
    """Return the full content of the current log file (for API responses)."""
    try:
        with open(config.LOG_FILE, encoding="utf-8") as fh:
            return fh.read()
    except FileNotFoundError:
        return ""
