"""
streamlit_app.py – Simple Streamlit UI for AutoPilot AI.

Run:
    streamlit run streamlit_app.py
"""

import asyncio
import json
import os
import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, os.path.dirname(__file__))
import config
from executor import BrowserAgent
from planner import generate_steps

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AutoPilot AI",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: 800;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0;
    }
    .sub-header { color: #888; margin-top: 0; margin-bottom: 2rem; }
    .step-card {
        background: #1e1e2e;
        border-left: 4px solid #667eea;
        border-radius: 8px;
        padding: 0.75rem 1rem;
        margin: 0.4rem 0;
        font-family: 'Courier New', monospace;
        font-size: 0.85rem;
    }
    .success-badge { color: #4ade80; font-weight: bold; }
    .fail-badge    { color: #f87171; font-weight: bold; }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Settings")
    headless = st.toggle("Headless Browser", value=True)
    max_retries = st.slider("Max Retries", 1, 5, config.MAX_RETRIES)
    st.markdown("---")
    st.markdown("### 🧪 Demo Tasks")
    demo_tasks = [
        "Open google and search AI tools",
        "Go to amazon and search laptops",
        "Open Wikipedia and search Python programming",
        "Fill the sample form at httpbin.org",
    ]
    selected_demo = st.selectbox("Pick a demo", [""] + demo_tasks)
    st.markdown("---")
    st.markdown("### 📚 About")
    st.markdown(
        "AutoPilot AI uses **Mercury LLM** to plan tasks and "
        "**Playwright** to execute them in a real browser."
    )


# ── Main ──────────────────────────────────────────────────────────────────────
st.markdown('<p class="main-header">🤖 AutoPilot AI</p>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">Intelligent Browser Automation Agent</p>', unsafe_allow_html=True)

task_input = st.text_input(
    "Describe what you want to automate",
    value=selected_demo,
    placeholder="e.g. Open google and search AI tools",
)

run_btn = st.button("▶ Run Task", type="primary", use_container_width=True)

if run_btn and task_input.strip():
    config.HEADLESS = headless
    config.MAX_RETRIES = max_retries

    col1, col2 = st.columns([1, 1])

    with col1:
        st.markdown("### 📋 Planning Steps")
        with st.spinner("Asking Mercury LLM to plan …"):
            steps = asyncio.run(generate_steps(task_input.strip()))

        for i, s in enumerate(steps, 1):
            action_emoji = {
                "open_url": "🌐", "click": "🖱️", "type": "⌨️",
                "extract": "📦", "wait": "⏳", "scroll": "↕️",
            }.get(s["action"], "❔")
            st.markdown(
                f'<div class="step-card">{action_emoji} <b>Step {i}</b>: '
                f'{s["description"]}<br/>'
                f'<span style="color:#888">action={s["action"]} '
                f'selector={s.get("selector","–")!r} '
                f'value={s.get("value","–")!r}</span></div>',
                unsafe_allow_html=True,
            )

    with col2:
        st.markdown("### 🚀 Execution")
        progress = st.progress(0)
        status_box = st.empty()

        async def _exec():
            agent = BrowserAgent()
            return await agent.execute_steps(steps)

        with st.spinner("Running in browser …"):
            result = asyncio.run(_exec())

        progress.progress(100)
        status_box.success("✅ Task completed!")

        # Summary metrics
        m1, m2, m3 = st.columns(3)
        m1.metric("Steps Run",  result["steps_executed"])
        m2.metric("Errors",     len(result["errors"]))
        m3.metric("Screenshots", len(result["screenshots"]))

        # Extracted data
        if result["extracted_data"]:
            st.markdown("#### 📦 Extracted Data")
            st.json(result["extracted_data"])

        # Errors
        if result["errors"]:
            st.markdown("#### ⚠️ Errors")
            for err in result["errors"]:
                st.error(err)

        # Screenshots
        if result["screenshots"]:
            st.markdown("#### 🖼️ Screenshots")
            for ss_path in result["screenshots"]:
                if Path(ss_path).exists():
                    st.image(ss_path, use_column_width=True)

elif run_btn:
    st.warning("Please enter a task first.")
