"""
main.py – FastAPI server for AutoPilot AI.

Endpoints
---------
POST /run-task       Run a natural-language browser task.
GET  /health         Liveness check.
GET  /screenshots    List captured screenshot filenames.
GET  /logs           Return the current log file contents.
"""

import asyncio
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

import config
from executor import BrowserAgent
from logger import get_logger, read_log_file
from planner import generate_steps

log = get_logger(__name__)

# ── App setup ─────────────────────────────────────────────────────────────────
app = FastAPI(
    title="AutoPilot AI",
    description="Intelligent Browser Automation Agent powered by Mercury LLM + Playwright",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve screenshots as static files
Path(config.SCREENSHOTS_DIR).mkdir(parents=True, exist_ok=True)
app.mount(
    "/screenshots",
    StaticFiles(directory=config.SCREENSHOTS_DIR),
    name="screenshots",
)


# ── Request / Response models ─────────────────────────────────────────────────

class TaskRequest(BaseModel):
    task: str = Field(..., min_length=3, max_length=500, example="Open google and search AI tools")


class TaskResponse(BaseModel):
    status: str
    task: str
    steps: list[dict[str, Any]]
    result: dict[str, Any]
    logs: str
    screenshots: list[str]
    duration_seconds: float


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "service": "AutoPilot AI"}


@app.post("/run-task", response_model=TaskResponse)
async def run_task(req: TaskRequest):
    """
    Accept a natural-language task, plan it with Mercury LLM,
    execute it in Playwright, and return structured results.
    """
    log.info("=== New task: %s ===", req.task)
    t_start = time.monotonic()

    # 1. Plan
    try:
        steps = await generate_steps(req.task)
    except Exception as exc:
        log.error("Planning failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Planning error: {exc}")

    # 2. Execute
    agent = BrowserAgent()
    try:
        result = await agent.execute_steps(steps)
    except Exception as exc:
        log.error("Execution failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Execution error: {exc}")

    duration = round(time.monotonic() - t_start, 2)

    # 3. Compose response
    status = "success" if not result["errors"] else "partial"
    log.info("Task finished in %.2fs with status=%s.", duration, status)

    return TaskResponse(
        status=status,
        task=req.task,
        steps=steps,
        result=result,
        logs=read_log_file(),
        screenshots=result["screenshots"],
        duration_seconds=duration,
    )


@app.get("/logs")
async def get_logs():
    return {"logs": read_log_file()}


@app.get("/screenshots")
async def list_screenshots():
    ss_dir = Path(config.SCREENSHOTS_DIR)
    files = sorted(ss_dir.glob("*.png"), key=lambda p: p.stat().st_mtime, reverse=True)
    return {"screenshots": [f.name for f in files[:50]]}


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=config.API_HOST, port=config.API_PORT, reload=True)
