# 🤖 AutoPilot AI – Intelligent Browser Automation Agent

> "ChatGPT controlling a browser automatically."

AutoPilot AI converts plain English instructions into fully automated browser sessions using **Mercury LLM** (Inception AI) for task planning and **Playwright** for execution — all wrapped in a production-ready **FastAPI** service with an optional **Streamlit** UI and **CLI**.

---

## ✨ Features

| Feature | Details |
|---|---|
| 🧠 Natural-language task planning | Mercury LLM converts any task into structured browser steps |
| 🌐 Real browser execution | Playwright (Chromium) runs steps in a real headless browser |
| 🔄 Retry mechanism | Each step retried up to 3× with configurable back-off |
| 🎯 Multi-strategy selectors | CSS → XPath → text-selector fallback chain |
| 🍪 Auto popup dismissal | Detects and closes cookie banners & modal dialogs |
| 📸 Auto screenshots | Screenshot after every step, saved with timestamp |
| 📦 Structured extraction | All scraped data returned as JSON |
| 🪵 Full logging | Per-run logs to file + in-response transcript |
| 🚀 FastAPI REST API | Clean async API with Pydantic validation |
| 🖥️ Streamlit UI | Visual front-end for non-technical users |
| ⌨️ CLI | Terminal interface with interactive REPL mode |

---

## 🏗️ Architecture

```
User Input (natural language)
        │
        ▼
┌──────────────────┐     Mercury LLM API
│   planner.py     │◄───(Inception AI)
│  generate_steps()│
└──────┬───────────┘
       │  structured steps (JSON)
       ▼
┌──────────────────┐     Playwright (Chromium)
│   executor.py    │◄───(async browser)
│  BrowserAgent    │
│  • open_url      │
│  • click         │
│  • type          │     ┌──────────────┐
│  • extract       │────►│ screenshots/ │
│  • wait          │     └──────────────┘
└──────┬───────────┘
       │
       ▼
┌──────────────────┐
│    main.py       │  POST /run-task
│  FastAPI server  │◄────────────────── REST client / Streamlit / CLI
└──────────────────┘
```

---

## 📁 Project Structure

```
autopilot-ai/
├── main.py           # FastAPI server + /run-task endpoint
├── planner.py        # Mercury LLM task planner
├── executor.py       # Playwright browser agent
├── logger.py         # Structured logging system
├── utils.py          # Shared helpers (retry, selectors, JSON parsing)
├── config.py         # All settings (reads from .env)
├── cli.py            # Command-line interface
├── streamlit_app.py  # Streamlit web UI (bonus)
├── screenshots/      # Auto-captured PNG screenshots
├── logs/
│   └── run.log       # Persistent execution log
├── .env.example      # Environment variable template
├── requirements.txt
└── README.md
```

---

## ⚙️ Setup Instructions

### 1. Clone / download the project

```bash
git clone https://github.com/yourname/autopilot-ai.git
cd autopilot-ai
```

### 2. Create a virtual environment

```bash
python -m venv venv
source venv/bin/activate        # Linux / macOS
venv\Scripts\activate           # Windows
```

### 3. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 4. Install Playwright browsers

```bash
playwright install chromium
playwright install-deps          # Linux only: system dependencies
```

### 5. Configure environment variables

```bash
cp .env.example .env
# Edit .env and add your MERCURY_API_KEY
```

> **Note:** If `MERCURY_API_KEY` is left empty the system falls back to a
> built-in keyword-based planner so you can still run demos without an API key.

---

## 🚀 How to Run

### Option A – FastAPI server

```bash
python main.py
# or
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

API docs available at: http://localhost:8000/docs

### Option B – Streamlit UI

```bash
# Start the FastAPI server first (in another terminal), then:
streamlit run streamlit_app.py
```

Open: http://localhost:8501

### Option C – CLI

```bash
# Single task
python cli.py "Search for AI tools on Google"

# Watch the browser (non-headless)
python cli.py "Go to Amazon and search laptops" --no-headless

# Interactive REPL
python cli.py --interactive

# JSON output
python cli.py "Search Python on Google" --json
```

---

## 📡 API Reference

### `POST /run-task`

Execute a browser automation task.

**Request body:**
```json
{
  "task": "Search laptops under 50000 on Amazon and get top 3 prices",
  "headless": true
}
```

**Response:**
```json
{
  "run_id": "a3f2c1b0",
  "status": "success",
  "task": "Search laptops under 50000 on Amazon ...",
  "steps": [
    {"action": "open_url",  "selector": "", "value": "https://www.amazon.in", "description": "Open Amazon"},
    {"action": "type",      "selector": "input#twotabsearchtextbox", "value": "laptops under 50000", "description": "Search"},
    ...
  ],
  "result": {
    "steps_executed": 7,
    "steps_succeeded": 7,
    "steps_failed": 0,
    "extracted_data": {
      "prices": ["₹34,990", "₹42,999", "₹49,499"]
    }
  },
  "logs": "2024-01-15 10:23:01  INFO  ...",
  "screenshots": ["screenshots/step_001_open_url_20240115_102301.png", ...],
  "error": null
}
```

**Status values:**
- `success` – all steps passed
- `partial` – some steps failed but execution continued
- `error` – unrecoverable failure

### `GET /health`

```json
{"status": "ok", "service": "AutoPilot AI"}
```

### `GET /screenshots`

Returns list of the 50 most recent screenshot filenames.

---

## 🧪 Demo Tasks

| Task | What it does |
|---|---|
| `"Open google and search AI tools"` | Google search with result extraction |
| `"Go to amazon and search laptops"` | Amazon product search + price scraping |
| `"Fill a sample form"` | Form fill on demoqa.com |
| `"Search python tutorials on google and extract top results"` | Multi-step research task |

---

## 🔧 Configuration Reference

| Variable | Default | Description |
|---|---|---|
| `MERCURY_API_KEY` | – | Your Inception AI key |
| `MERCURY_MODEL` | `mercury-coder-small` | Model name |
| `BROWSER_HEADLESS` | `true` | Run headless |
| `BROWSER_SLOW_MO` | `50` | ms delay between actions |
| `DEFAULT_TIMEOUT` | `15000` | Element wait timeout (ms) |
| `NAVIGATION_TIMEOUT` | `30000` | Page load timeout (ms) |
| `MAX_RETRIES` | `3` | Per-step retry count |
| `RETRY_DELAY` | `1.5` | Seconds between retries |

---

## 🤝 Contributing

Pull requests welcome!  Please open an issue first to discuss what you'd like to change.

---

## 📄 License

MIT
