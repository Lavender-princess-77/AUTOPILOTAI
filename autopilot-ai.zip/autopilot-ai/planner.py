"""
planner.py – LLM-powered task planner using Mercury (Inception AI).

Public API
----------
    steps = await generate_steps("Open google and search AI tools")

Each step is a dict:
    {
        "action":      "open_url" | "click" | "type" | "extract" | "wait" | "scroll",
        "selector":    "<CSS / XPath / text selector or empty>",
        "value":       "<URL, text to type, seconds to wait, etc.>",
        "description": "<human-readable explanation>"
    }
"""

import json
from typing import Any

import httpx

import config
from logger import get_logger
from utils import extract_json_from_text

log = get_logger(__name__)

# ── System prompt ─────────────────────────────────────────────────────────────
_SYSTEM_PROMPT = """
You are AutoPilot AI, an expert browser automation planner.
Given a natural-language task, output ONLY a JSON array of steps.
Each step must be a JSON object with these exact keys:
  "action"      – one of: open_url, click, type, extract, wait, scroll
  "selector"    – CSS selector, XPath (prefix //), or "text=<visible text>" (empty string for open_url/wait)
  "value"       – URL for open_url; text for type; seconds (string) for wait; empty for click/extract/scroll
  "description" – one short sentence explaining what this step does

Rules:
- Prefer widely-supported CSS selectors; use XPath only when necessary.
- For searches, use the search-box selector and submit via the Enter key in the value field (type action value should end with \\n to trigger submit).
- Always start with an open_url step.
- Extract meaningful content using the extract action.
- Output ONLY the JSON array, no commentary, no markdown fences.

Example output:
[
  {"action":"open_url","selector":"","value":"https://www.google.com","description":"Open Google homepage"},
  {"action":"type","selector":"textarea[name='q']","value":"AI tools\\n","description":"Search for AI tools"},
  {"action":"wait","selector":"","value":"2","description":"Wait for results to load"},
  {"action":"extract","selector":"h3","value":"","description":"Extract result titles"}
]
""".strip()


# ── Fallback steps for common task patterns ───────────────────────────────────
_FALLBACK_PATTERNS: dict[str, list[dict]] = {
    "google": [
        {"action": "open_url",  "selector": "", "value": "https://www.google.com", "description": "Open Google"},
        {"action": "type",      "selector": "textarea[name='q']", "value": "{query}\n", "description": "Type search query"},
        {"action": "wait",      "selector": "", "value": "2", "description": "Wait for results"},
        {"action": "extract",   "selector": "h3", "value": "", "description": "Extract result titles"},
    ],
    "amazon": [
        {"action": "open_url",  "selector": "", "value": "https://www.amazon.in", "description": "Open Amazon India"},
        {"action": "type",      "selector": "#twotabsearchtextbox", "value": "{query}\n", "description": "Search on Amazon"},
        {"action": "wait",      "selector": "", "value": "2", "description": "Wait for results"},
        {"action": "extract",   "selector": "span.a-price-whole", "value": "", "description": "Extract prices"},
        {"action": "extract",   "selector": "span.a-size-medium.a-color-base.a-text-normal", "value": "", "description": "Extract product names"},
    ],
    "form": [
        {"action": "open_url",  "selector": "", "value": "https://httpbin.org/forms/post", "description": "Open sample form"},
        {"action": "type",      "selector": "input[name='custname']", "value": "AutoPilot User", "description": "Fill customer name"},
        {"action": "type",      "selector": "input[name='custtel']",  "value": "9999999999",   "description": "Fill phone number"},
        {"action": "click",     "selector": "button[type='submit']",  "value": "",             "description": "Submit form"},
        {"action": "wait",      "selector": "", "value": "2", "description": "Wait for response"},
        {"action": "extract",   "selector": "body", "value": "", "description": "Extract response body"},
    ],
}


def _pick_fallback(task: str) -> list[dict]:
    """Return heuristic steps when the LLM call fails."""
    tl = task.lower()
    for keyword, steps in _FALLBACK_PATTERNS.items():
        if keyword in tl:
            # Inject the task text as the query where applicable
            query = task
            return [
                {**s, "value": s["value"].replace("{query}", query)}
                for s in steps
            ]
    # Generic fallback – just open Google and search
    return [
        {"action": "open_url", "selector": "", "value": "https://www.google.com",
         "description": "Open Google (generic fallback)"},
        {"action": "type",     "selector": "textarea[name='q']", "value": task + "\n",
         "description": "Search for the task"},
        {"action": "wait",     "selector": "", "value": "2", "description": "Wait for results"},
        {"action": "extract",  "selector": "h3", "value": "", "description": "Extract titles"},
    ]


async def generate_steps(task: str) -> list[dict[str, Any]]:
    """
    Call Mercury LLM to convert *task* into a list of automation steps.
    Falls back to heuristic steps on any error.
    """
    if not config.MERCURY_API_KEY:
        log.warning("MERCURY_API_KEY not set – using fallback planner.")
        return _pick_fallback(task)

    payload = {
        "model": config.MERCURY_MODEL,
        "max_tokens": config.LLM_MAX_TOKENS,
        "temperature": config.LLM_TEMPERATURE,
        "system": _SYSTEM_PROMPT,
        "messages": [
            {"role": "user", "content": f"Task: {task}"}
        ],
    }

    headers = {
        "Authorization": f"Bearer {config.MERCURY_API_KEY}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            log.info("Calling Mercury LLM for task: %s", task)
            resp = await client.post(
                f"{config.MERCURY_BASE_URL}/messages",
                json=payload,
                headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()

        # Extract text from the response
        raw_text: str = ""
        for block in data.get("content", []):
            if block.get("type") == "text":
                raw_text += block["text"]

        if not raw_text:
            raise ValueError("Empty response from Mercury API")

        steps = extract_json_from_text(raw_text)

        if not isinstance(steps, list) or not steps:
            raise ValueError("LLM returned empty or non-list steps")

        log.info("Planner produced %d steps via LLM.", len(steps))
        return steps

    except Exception as exc:
        log.warning("LLM planning failed (%s) – switching to fallback.", exc)
        fallback = _pick_fallback(task)
        log.info("Fallback produced %d steps.", len(fallback))
        return fallback
