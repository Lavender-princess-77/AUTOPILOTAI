"""
config.py – Central configuration for AutoPilot AI.
All tuneable knobs live here so the rest of the codebase stays clean.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ── Mercury / Inception AI ──────────────────────────────────────────────────
MERCURY_API_KEY: str = os.getenv("MERCURY_API_KEY", "")
MERCURY_BASE_URL: str = os.getenv(
    "MERCURY_BASE_URL", "https://api.inceptionlabs.ai/v1"
)
MERCURY_MODEL: str = os.getenv("MERCURY_MODEL", "mercury-coder-small")

# ── Browser ─────────────────────────────────────────────────────────────────
HEADLESS: bool = os.getenv("HEADLESS", "true").lower() == "true"
BROWSER_TIMEOUT: int = int(os.getenv("BROWSER_TIMEOUT", "30000"))   # ms
NAVIGATION_TIMEOUT: int = int(os.getenv("NAVIGATION_TIMEOUT", "60000"))  # ms
SLOW_MO: int = int(os.getenv("SLOW_MO", "0"))   # ms between actions

# ── Retry ────────────────────────────────────────────────────────────────────
MAX_RETRIES: int = int(os.getenv("MAX_RETRIES", "3"))
RETRY_DELAY: float = float(os.getenv("RETRY_DELAY", "1.5"))   # seconds

# ── Paths ────────────────────────────────────────────────────────────────────
SCREENSHOTS_DIR: str = os.getenv("SCREENSHOTS_DIR", "screenshots")
LOGS_DIR: str = os.getenv("LOGS_DIR", "logs")
LOG_FILE: str = os.path.join(LOGS_DIR, "run.log")

# ── FastAPI ──────────────────────────────────────────────────────────────────
API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
API_PORT: int = int(os.getenv("API_PORT", "8000"))

# ── LLM Generation ───────────────────────────────────────────────────────────
LLM_MAX_TOKENS: int = int(os.getenv("LLM_MAX_TOKENS", "1024"))
LLM_TEMPERATURE: float = float(os.getenv("LLM_TEMPERATURE", "0.2"))

# ── Popup selectors to auto-dismiss ─────────────────────────────────────────
POPUP_SELECTORS: list = [
    "button:has-text('Accept')",
    "button:has-text('Accept all')",
    "button:has-text('Accept cookies')",
    "button:has-text('I agree')",
    "button:has-text('Agree')",
    "button:has-text('Close')",
    "button:has-text('No thanks')",
    "button:has-text('Dismiss')",
    "[aria-label='Close']",
    "[aria-label='Dismiss']",
    ".cookie-accept",
    "#onetrust-accept-btn-handler",
    ".fc-cta-consent",
]
